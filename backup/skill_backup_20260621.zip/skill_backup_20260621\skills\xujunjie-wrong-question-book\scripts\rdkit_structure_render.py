#!/usr/bin/env python3
"""Render a chemistry structure with RDKit and print a suggested Word size."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


PRESETS = {
    "option-inline": {"px": (320, 120), "word_width_in": 1.2},
    "option-single": {"px": (520, 180), "word_width_in": 1.8},
    "option-wide": {"px": (760, 220), "word_width_in": 2.6},
    "reaction-small": {"px": (920, 260), "word_width_in": 3.2},
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smiles", required=True, help="Structure as SMILES.")
    parser.add_argument(
        "--preset",
        choices=sorted(PRESETS),
        default="option-single",
        help="Canvas preset matched to the intended Word insertion size.",
    )
    parser.add_argument("--out", required=True, type=Path, help="Output PNG path.")
    parser.add_argument("--legend", default="", help="Optional small label under the structure.")
    parser.add_argument("--padding", type=float, default=0.08, help="RDKit drawing padding.")
    parser.add_argument(
        "--background",
        choices=("transparent", "white"),
        default="transparent",
        help="Background style for the exported PNG.",
    )
    return parser


def import_rdkit():
    try:
        from rdkit import Chem
        from rdkit.Chem.Draw import rdMolDraw2D
    except ImportError as exc:
        raise SystemExit(
            "RDKit is not available in the current Python environment. "
            "Install or switch to an environment that provides `rdkit` before rendering."
        ) from exc
    return Chem, rdMolDraw2D


def render(smiles: str, preset_name: str, out_path: Path, legend: str, padding: float, background: str) -> dict[str, object]:
    Chem, rdMolDraw2D = import_rdkit()

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise SystemExit(f"Unable to parse SMILES: {smiles}")

    Chem.rdDepictor.Compute2DCoords(mol)
    width, height = PRESETS[preset_name]["px"]

    drawer = rdMolDraw2D.MolDraw2DCairo(width, height)
    options = drawer.drawOptions()
    options.padding = padding
    options.legendFontSize = 18
    if background == "transparent":
        options.clearBackground = False

    rdMolDraw2D.PrepareAndDrawMolecule(drawer, mol, legend=legend)
    drawer.FinishDrawing()
    png_bytes = drawer.GetDrawingText()

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(png_bytes)

    return {
        "smiles": smiles,
        "preset": preset_name,
        "output": str(out_path),
        "pixel_width": width,
        "pixel_height": height,
        "suggested_word_width_in": PRESETS[preset_name]["word_width_in"],
    }


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    result = render(
        smiles=args.smiles,
        preset_name=args.preset,
        out_path=args.out,
        legend=args.legend,
        padding=args.padding,
        background=args.background,
    )
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
