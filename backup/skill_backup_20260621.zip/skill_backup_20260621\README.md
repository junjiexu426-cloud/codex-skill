# Skill Backup

This folder is a backup of the non-system skills currently stored under `C:\Users\许俊杰\.codex\skills`.

Included skills:

- `final-exam-review`
- `research-vault-literature-retrieval`
- `wrong-question-book`
- `xujunjie-wrong-question-book`
- `zotero-analytical-writer`
- `zotero-collection-manager`
- `zotero-data-fetcher`

Not included:

- `.system`
  Those are system-provided skills rather than your own installed skill folders.

Restore steps:

1. Reinstall Codex if needed.
2. Copy the folders inside `skills\` back to `C:\Users\许俊杰\.codex\skills\`.
3. Restart Codex.

GitHub upload status:

- A direct upload is not available yet from this environment because no writable GitHub repository is currently connected here.
- The GitHub connector returned no accessible repositories.
- GitHub CLI `gh` is not installed on this machine.

Fastest next step:

- Connect a GitHub repository to Codex, or
- install and log in to GitHub CLI, then this backup folder can be uploaded directly.
