#!/usr/bin/env python3
"""Fail delivery when DOCX math contains unbuilt linear structure markers."""

import argparse
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


NS = {
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
}
SUPERSCRIPT_CHARS = set("⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿ")
SUBSCRIPT_CHARS = set("₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎")


def audit(path: Path) -> list[str]:
    problems: list[str] = []
    try:
        with zipfile.ZipFile(path) as archive:
            parts = [
                name
                for name in archive.namelist()
                if name.startswith("word/") and name.endswith(".xml")
            ]
    except (OSError, KeyError, zipfile.BadZipFile) as exc:
        return [f"无法读取 DOCX：{exc}"]

    formula_index = 0
    with zipfile.ZipFile(path) as archive:
        for part in parts:
            root = ET.fromstring(archive.read(part))
            for math in root.findall(".//m:oMath", NS):
                formula_index += 1
                text = "".join(math.itertext())
                location = f"{part} 中的公式 {formula_index}"
                if "^" in text:
                    problems.append(f"{location} 含裸 ^，指数未搭建为 m:sSup：{text}")
                if "_" in text:
                    problems.append(f"{location} 含裸 _，下标未搭建为 m:sSub：{text}")
                if any(char in SUPERSCRIPT_CHARS for char in text):
                    problems.append(f"{location} 使用 Unicode 上标字符而非 m:sSup：{text}")
                if any(char in SUBSCRIPT_CHARS for char in text):
                    problems.append(f"{location} 使用 Unicode 下标字符而非 m:sSub：{text}")
                if re.search(r"\\(?:frac|sqrt|sum|int|hat|bar|vec)\b", text):
                    problems.append(f"{location} 含未转换的 LaTeX 命令：{text}")

    return problems


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="backslashreplace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", nargs="+", type=Path)
    args = parser.parse_args()
    failed = False
    for path in args.docx:
        problems = audit(path)
        if problems:
            failed = True
            print(f"FAIL {path}")
            for problem in problems:
                print(f"  - {problem}")
        else:
            print(f"PASS {path}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
