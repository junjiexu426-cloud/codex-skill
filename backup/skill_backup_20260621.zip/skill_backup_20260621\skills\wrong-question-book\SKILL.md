---
name: wrong-question-book
description: Compile wrong questions from exam papers, Word files, scanned PDFs, or phone photos into practice and answer-analysis documents. Use for "整理错题", "错题本", photographed marked homework, multiple exam images, red-pen corrections, answer comparison, or extracting selected questions. Supports any subject and requires conservative visual verification for formulas, chemical structures, handwriting, and incomplete photos.
---

# Wrong Question Book Generator

Compile incorrectly-answered exam questions into two polished Word documents: one practice-only version (questions only) and one with full answers and explanations.

## Quick Reference

| User says | Meaning |
|-----------|---------|
| `整理错题 历史 2018卷:4,14,15` | Subject=历史, 2018 paper, extract Q4,14,15 |
| `/答案 2018:DABCC` | Answer key for 2018 questions in order |
| `/我的答案 2025:BDACAD` | User's answers (for comparison mode) |
| `/标准答案 2025:BDCCAD` | Standard answers (auto-detect wrong ones) |

## Input Protocol

Three input modes. Default to Mode 1 unless user provides answer strings.

### Mode 1: Direct Question Numbers
```
整理错题 <科目> <试卷标识>:<题号列表>
```
Example: `整理错题 高等数学 2024期末:3,7,12,15`

### Mode 2: Answer Comparison (auto-detect errors)
```
整理错题 <科目> <试卷标识>
/我的答案 <answer_string>
/标准答案 <answer_string>
```
Auto-compares and extracts only wrong answers.

### Mode 3: Mixed (multiple papers with answers)
```
整理错题 历史 2018卷:4,14,15,17,19,21,30 2020卷:7,10,11
/答案 2018:DABCCBD 2020:BCADCCABDA
```

## Workflow

```
User input → Find PDF in papers directory →
Extract text (pdfplumber or tesseract OCR for scans) →
Extract specific questions by number →
(Optional) Compare answers →
Generate question JSON →
Generate Word docs via docx skill's docx-js pattern
```

## Prerequisites

- `pdfplumber` for text-native PDFs
- `python-docx` for Word document input
- `pytesseract` + `pdf2image` for scanned PDFs (Chinese: `chi_sim.traineddata` in `~/.tessdata/`)
- `docx` npm package for Word generation
- Tesseract: Windows at `C:\Program Files\Tesseract-OCR\tesseract.exe`

## Supported Input Formats

PDF, DOCX, JPG, JPEG, PNG, WEBP, BMP, and TIFF are supported.

## Photo Workflow

When input contains photos, do not treat OCR as authoritative.

1. Open and visually inspect every image.
2. Correct EXIF rotation; rotate manually if text is still sideways.
3. Group overlapping photos and remove duplicates.
4. Identify wrong questions using evidence:
   - high confidence: teacher cross/correction plus a visible corrected answer;
   - medium confidence: teacher cross or score deduction without a visible answer;
   - low confidence: ambiguous circles, student notes, or cropped markings.
5. Extract the complete question boundary, including the stem, options, diagrams, and tables. Label missing content `题干不完整`.
6. Run OCR only as a draft, then compare it line by line with the image.
7. Transcribe formulas and chemical structures conservatively:
   - preserve subscripts, superscripts, charges, arrows, fractions, and exponents;
   - describe a structure in words when faithful text representation is impossible;
   - never infer hidden bonds, coefficients, options, or answer keys.
8. Separate the student's answer, teacher correction, and verified answer. Do not assume a circled option is the student's final answer.
9. Assign each item a confidence level: `高`, `中`, or `低`.
10. Ask for a clearer photo only when missing content prevents a reliable answer. Otherwise continue and mark uncertainty.

### Figures and Diagrams

When a question contains a figure, diagram, graph, geometric construction, apparatus, or chemical illustration:

1. Crop and preserve the original figure whenever it is readable. The original is the authoritative source.
2. Use the `imagegen` skill with the image-2 model to create a clean replacement only when the original is blurry, skewed, marked over, or unsuitable for the final document.
3. Give image-2 a precise reconstruction prompt containing every visible label, value, axis, point, connection, orientation, and relative position.
4. Generate a neutral textbook-style diagram. Do not add decorative content.
5. Compare the generated diagram against the original before use. Reject it if any label, value, topology, scale relationship, chemical bond, or answer-relevant detail changes.
6. Add `示意图（根据原图重绘）` below generated figures. If faithful reconstruction is uncertain, keep the original image and mark `图示待核实`.
7. Never use generative reconstruction for an answer-critical figure when missing or hidden details cannot be verified.

For chemical structures, prefer a deterministic chemistry drawing tool when available. Use image-2 only for faithful visual cleanup, never to infer a hidden structure.

### Tables in Word

When a question contains a table, recreate it as a native Word table instead of embedding a screenshot whenever the cells are readable.

- Preserve the exact row and column count, merged cells, headers, symbols, units, formulas, and blank answer cells.
- Use explicit column widths and allow rows to expand; never use fixed row heights that can clip text.
- Center short values and headers; left-align long text.
- Repeat header rows when a table spans pages.
- Use Microsoft YaHei for Chinese and a math-capable font for formulas when needed.
- Visually compare the recreated table with the source before delivery.
- If any cell is unreadable, write `待核实` in that cell and include the source crop below the table.

For Word deliverables, use the documents skill and complete its render-and-inspect workflow. Keep diagrams with their captions and keep tables with their question stems when possible.

### Mandatory Conflict Check

Before finalizing each answer:

- Recalculate math and science answers independently.
- If a teacher mark conflicts with the visible question or calculation, state the conflict and mark the answer `待核实`.
- If an official answer is not visible and independent verification is not possible, use `待核实`; never fabricate.

### Photo Output Fields

For every photo-derived item, preserve:

- source image filename;
- visible question number;
- question text and options;
- student's visible answer, if identifiable;
- teacher mark or correction;
- verified answer or `待核实`;
- explanation and mistake pattern;
- confidence level;
- missing/cropped content note.
- original or reconstructed figure, when present;
- native Word table, when present.

## Implementation

### Step 1: Extract text from PDF

Use `ocr_extract.py` - handles both text-native and scanned PDFs automatically:
```bash
python ~/.claude/skills/wrong-question-book/ocr_extract.py <pdf_path>
```

### Step 2: Extract questions and build JSON

Use `generate.py`:
```bash
python ~/.claude/skills/wrong-question-book/generate.py \
  --subject <科目> --papers-dir <PDF目录> --output <输出目录> \
  "2018卷:4,14,15,17,19,21,30" "2020卷:7,10,11"
```

The script outputs `extracted_questions.json` with per-year question arrays.

### Step 3: Add explanations

For each question in the JSON, add:
```json
{
  "num": 4,
  "text": "完整题目文本...",
  "options": ["选项A", "选项B", "选项C", "选项D"],
  "answer": "D",
  "explanation": "解析内容：为什么选D，其他选项错在哪"
}
```

**Accuracy rule:** If the exam paper has an official answer key, use it. Otherwise, explain historically known answers. Never fabricate answers - mark uncertain ones as `"answer": "待核实"`.

### Step 4: Generate Word documents

Use `docx_generator.js`:
```bash
cd <output_dir> && node ~/.claude/skills/wrong-question-book/docx_generator.js \
  subject=<科目> input=extracted_questions.json
```

Generates two files:
- `错题-仅题目.docx` - practice version (questions only)
- `错题-题目加解析.docx` - with answers and explanations

## Subject Adaptation

The skill is subject-agnostic. Adapt explanation style per subject:

| Subject type | Explanation focus |
|-------------|-------------------|
| History/Politics | Timeline + cause-effect + context |
| Math/Physics | Formula derivation + solution steps |
| Chemistry/Bio | Mechanism + experiment + application |
| English/Language | Grammar + vocabulary + usage |
| CS/Engineering | Logic + algorithm + code |
| Others | Concept + principle + example |

**Key principle:** Subject metadata passes through from user input. Don't hardcode any subject assumptions.

## Common Mistakes

1. **Question 4 vs Instruction 4**: Exam papers have numbered instructions AND numbered questions. Check the text contains "（ ）" or actual exam content, not "考试结束后" or "答题卡".
2. **Scanned PDFs**: If pdfplumber returns empty, OCR is required. Check `extract_text_from_pdf()` return value's second element.
3. **Missing Chinese font**: Word docs use `Microsoft YaHei`. If unavailable, the docx skill defaults to Arial which won't display Chinese. Ensure font is installed.
4. **Answer indexing**: Answer strings map in ORDER to the questions list, NOT to question numbers. `2018:4,14,15` with answer `DAB` means Q4=D, Q14=A, Q15=B.

## Red Flags

- PDF returns garbled text: check if scanned (use OCR)
- 2025 paper not found: newer papers may use different naming
- "Unsupported Image": screenshots from PDF too large - reduce DPI or use text extraction
- tesseract Chinese not working: check `~/.tessdata/chi_sim.traineddata` exists
