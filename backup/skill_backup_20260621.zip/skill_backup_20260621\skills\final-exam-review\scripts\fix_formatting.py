#!/usr/bin/env python3
"""Fix markdown formatting in review document before PDF generation.

Handles:
  1. Exercise spacing (blank lines between questions)
  2. Table spacing (blank lines before tables)
  3. Remove ::: fenced div blocks (don't render in basic pandoc, may hide content)
  4. Replace Unicode chars that SimHei/LatinModern fonts lack
  5. Use > blockquote for visual emphasis (works in pandoc PDF, unlike ::: divs)

Guidelines for writing review content (Phase 2):
  - Write critical content with > blockquote for PDF visual indent + left bar
  - Use Chinese markers: 【重中之重】【重点】【易错】【公式】【关联】
  - Never use ::: fenced divs, ★/⚠/✓ Unicode symbols - they won't render
  - Ensure blank lines between every exercise question
  - Ensure blank lines before every markdown table
"""
import re
import sys
import os


def fix_exercise_spacing(lines):
    """Add blank lines between numbered exercise questions and bullet items."""
    result = []
    in_exercise = False

    for i, line in enumerate(lines):
        stripped = line.rstrip("\n").rstrip("\r")

        # Detect exercise section headers
        if re.match(r'^(###\s+第[0-9]+章\s+(学习通|PPT))|(####\s+(单选题|多选题|判断题))', stripped):
            in_exercise = True
            result.append(line)
            continue

        # End exercise section
        if in_exercise and (
            stripped.startswith("## ")
            or stripped == "---"
            or re.match(r'^###\s+第[0-9]+章\s+PPT', stripped)
        ):
            in_exercise = False
            result.append(line)
            continue

        if in_exercise:
            is_numbered = bool(re.match(r'^\d+\.\s', stripped))
            is_dash_bullet = bool(re.match(r'^-\s.*[\(（][√×✓✗]{1,2}[\)）]', stripped))
            is_q_bullet = bool(re.match(r'^\*\*Q\d+\*\*', stripped))

            if (is_numbered or is_dash_bullet or is_q_bullet) and i > 0:
                prev = lines[i-1].rstrip("\n").rstrip("\r")
                if prev.strip():
                    result.append("\n")

            result.append(line)
        else:
            result.append(line)

    return result


def fix_table_spacing(lines):
    """Ensure blank lines before all markdown tables."""
    result = []
    for i, line in enumerate(lines):
        stripped = line.rstrip("\n").rstrip("\r")
        if stripped.startswith("|") and i > 0:
            prev = lines[i-1].rstrip("\n").rstrip("\r")
            if prev.strip() and not prev.startswith("|"):
                result.append("\n")
        result.append(line)
    return result


def remove_fenced_divs(lines):
    """Remove ::: {.xxxbox} and matching ::: lines that don't render in basic pandoc.

    The content-classes.tex requires a Lua filter to convert ::: blocks to tcolorbox
    environments. Without it, the blocks may silently drop content. Safer to remove them
    and rely on existing markdown markers (★★★, ⚠️, > blockquotes) for emphasis.
    """
    result = []
    in_div = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith(":::") and "{" in stripped:
            in_div = True
            continue
        if in_div and stripped == ":::":
            in_div = False
            continue
        result.append(line)
    return result


# Unicode chars that SimHei/LatinModern fonts cannot render in PDF.
# Replace them with ASCII/text equivalents to ensure content accuracy.
UNICODE_REPLACEMENTS = [
    # (pattern, replacement)
    ("★★★", "【重中之重】"),               # U+2605 star
    ("★★", "【重点】"),
    ("⚠️", "【易错】"),                     # U+26A0 warning + U+FE0F
    ("⚠", "【易错】"),
    ("✓", "(Y)"),                          # U+2713 checkmark
    ("✗", "(N)"),                          # U+2717 cross
    ("≠", "!="),                           # U+2260 not equal
    ("≤", "<="),                           # U+2264 less-equal
    ("≥", ">="),                           # U+2265 greater-equal
    ("≈", "~="),                           # U+2248 approx
    ("①", "(1)"),                          # U+2460 circled 1
    ("②", "(2)"),                          # U+2461 circled 2
    ("③", "(3)"),
    ("④", "(4)"),
    ("⑤", "(5)"),
]

# Greek letters used in economics formulas
UNICODE_REPLACEMENTS += [
    ("ηx", "eta_x"),                       # U+03B7 eta (Marshall-Lerner)
    ("ηm", "eta_m"),
    ("η", "eta"),
]

def sanitize_unicode(lines):
    """Replace Unicode chars that cannot render in SimHei/LatinModern fonts."""
    result = []
    replaced_count = 0
    for line in lines:
        for pattern, replacement in UNICODE_REPLACEMENTS:
            if pattern in line:
                line = line.replace(pattern, replacement)
                replaced_count += 1
        result.append(line)
    if replaced_count > 0:
        print(f"  [OK] Unicode sanitized: {replaced_count} replacements")
    return result


def apply_all(md_path):
    """Apply all formatting fixes to the markdown file."""
    with open(md_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    lines = remove_fenced_divs(lines)
    lines = sanitize_unicode(lines)
    lines = fix_exercise_spacing(lines)
    lines = fix_table_spacing(lines)

    with open(md_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    print(f"  [OK] All formatting fixes applied: {md_path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 fix_formatting.py <markdown_file>")
        sys.exit(1)

    md_path = sys.argv[1]
    if not os.path.isfile(md_path):
        print(f"Error: file not found: {md_path}")
        sys.exit(1)

    apply_all(md_path)
