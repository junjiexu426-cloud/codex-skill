#!/usr/bin/env python3
"""Phase 1: Multi-engine extraction of all course materials."""
import os
import sys
import subprocess

ENGINES = {
    ".pptx": "markitdown",
    ".docx": "markitdown",
    ".pdf": "liteparse",   # handles both text-based and scanned PDFs
    ".png": "liteparse",
    ".jpg": "liteparse",
    ".txt": "direct",
    ".md": "direct",
}

def extract_file(filepath, engine):
    """Extract text from one file using the appropriate engine."""
    ext = os.path.splitext(filepath)[1].lower()
    engine = ENGINES.get(ext, "direct")

    if engine == "markitdown":
        from markitdown import MarkItDown
        md = MarkItDown()
        result = md.convert(filepath)
        return result.text_content

    elif engine == "liteparse":
        import liteparse
        if ext == ".pdf":
            doc = liteparse.PDFDocument(filepath)
        else:
            doc = liteparse.ImageDocument(filepath)
        return doc.get_markdown()

    elif engine == "direct":
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return f.read()
        except UnicodeDecodeError:
            with open(filepath, "r", encoding="gbk") as f:
                return f.read()

    return ""

def organize_into_chapters(text, filename):
    """Split extracted text into chapter sections based on slide markers."""
    chapters = {}
    current_ch = "unknown"
    current_lines = []

    for line in text.split("\n"):
        # Detect slide markers
        if line.strip().startswith("--- Slide") or "Slide" in line:
            if current_lines:
                chapters.setdefault(current_ch, []).extend(current_lines)
            current_lines = []
            continue

        # Detect chapter headings
        line_stripped = line.strip()
        lower = line_stripped.lower()

        if "chapter" in lower and ("balance" in lower or "exchange" in lower or
            "market" in lower or "reserve" in lower or "flow" in lower or
            "regime" in lower or "financial" in lower or "国际" in line_stripped):
            current_ch = line_stripped[:50]

        current_lines.append(line)

    if current_lines:
        chapters.setdefault(current_ch, []).extend(current_lines)

    return chapters

def extract_all(course_dir):
    """Extract all course materials in directory."""
    output_dir = os.path.join(course_dir, "__extracted__")
    os.makedirs(output_dir, exist_ok=True)

    files = os.listdir(course_dir)
    extracted_count = 0

    for fname in sorted(files):
        filepath = os.path.join(course_dir, fname)
        ext = os.path.splitext(fname)[1].lower()

        if ext not in ENGINES:
            continue
        if "_clean" in fname or "extracted" in fname:
            continue

        print(f"Extracting: {fname} ...")
        try:
            text = extract_file(filepath, ENGINES[ext])

            # Save extracted text
            base = os.path.splitext(fname)[0]
            out_path = os.path.join(output_dir, f"{base}.txt")
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(text)

            print(f"  -> {out_path} ({len(text)} chars)")
            extracted_count += 1
        except Exception as e:
            print(f"  [ERROR] {fname}: {e}")

    print(f"\nExtracted {extracted_count} files to {output_dir}/")
    return output_dir

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 extract_all.py <course_directory>")
        sys.exit(1)

    extract_all(sys.argv[1])
